//
//  LeftSideViewController.swift
//  Evee-Swift
//
//  Created by Kvana Inc 2 on 28/09/15.
//  Copyright (c) 2015 Kvana. All rights reserved.
//

import UIKit

class LeftSideViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var tableviewobject: UITableView!
    var optionsArray=["Main", "Swift", "Java", "Go", "NonMenu"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden=true
        self.view.backgroundColor=UIColor .white
        let tableviewobject:UITableView=UITableView()
        tableviewobject.frame=CGRectMake(0,40, self.view.frame.size.width, self.view.frame.size.height)
        self.view .addSubview(tableviewobject)
        
        tableviewobject.delegate=self
        tableviewobject.dataSource=self
        tableviewobject.tableFooterView = UIView(frame: CGRect.zero)
        tableviewobject.backgroundColor=UIColor.white
        tableviewobject.separatorColor=UIColor.black
    }
    
    
    //frame
    func CGRectMake(_ x: CGFloat, _ y: CGFloat, _ width: CGFloat, _ height: CGFloat) -> CGRect {
        return CGRect(x: x, y: y, width: width, height: height)
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return optionsArray.count
    }
    
    private func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 80;
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:UITableViewCell!=UITableViewCell(style: UITableViewCell.CellStyle.subtitle, reuseIdentifier: "tableviewcell")
        cell.backgroundColor=UIColor.clear
        cell.textLabel!.text=optionsArray[indexPath.row]
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if(indexPath.row == 3){
            tableView.beginUpdates()
            if(optionsArray.count == 5){
                for index in 1...optionsArray.count {
                    if(index == 1){
                        optionsArray.insert(" A", at: optionsArray.count-1)
                    }
                    else if(index == 2){
                        optionsArray.insert(" B", at: optionsArray.count-1)
                    }
                    else if(index == 3){
                        optionsArray.insert(" C", at: optionsArray.count-1)
                    }
                    else if(index == 4){
                        optionsArray.insert(" D", at: optionsArray.count-1)
                    }
                    else if(index == 5){
                        optionsArray.insert(" E", at: optionsArray.count-1)
                    }
                    tableView.insertRows(at: [
                        (NSIndexPath(row: optionsArray.count-2, section: 0) as IndexPath)], with: .automatic)
                    
                }
            }
            else{
                for index in 1...optionsArray.count {
                    if(index == 1 || index == 2 || index == 3 || index == 4 || index == 5){
                        optionsArray.remove(at: optionsArray.count-1)
                    }
                    let indexPath = IndexPath(item: optionsArray.count-1, section: 0)
                    tableView.deleteRows(at: [indexPath], with: .fade)
                }
            }
            
            
            
            tableView.endUpdates()
            
            
        }
        var vc:UIViewController;
        
        if(indexPath.row == 0){
            
            vc=(self.storyboard?.instantiateViewController(withIdentifier: "ViewController"))!
            SlideNavigationController.sharedInstance().popAllAndSwitch(to: vc) { () -> Void in
                
            };
        }
        if(indexPath.row == 1){
            vc=(self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController"))!
            SlideNavigationController.sharedInstance().popAllAndSwitch(to: vc) { () -> Void in
                
            };
        }
        
        
        
        
    }
    
    
    
    
    
}
